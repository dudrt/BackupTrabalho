package com.example.climating;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONException;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class LocalStorage {





}
